
public class RUN {   
	
	// This is how you start the game!!
  
	public static void main(String args[]){
		new GameWindow();
	}
}

